package org.com.UIPath;

import java.io.File;
import java.io.FileInputStream;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtilities {
    private XSSFWorkbook workBook;

    private XSSFSheet workSheet;
    
    private String testDataFilePath;  

    public boolean getTestDataSheet(String ApplicationName) {
        try {
            setTestDataPath();
            if (new File(getTestDataPath() + "/" + ApplicationName + "/" + ApplicationName + ".xlsx").exists()) {
                return true;
            }
        } catch (Exception e) {

            System.out.println(e);
        }
        return false;
    }

    public XSSFWorkbook getWorkBook(String ApplicationName) {

        try {
            workBook = new XSSFWorkbook(new FileInputStream(
                    new File(getTestDataPath() + "/" + ApplicationName + "/" + ApplicationName + ".xlsx")));
        } catch (Exception e) {

            System.out.println(e);
        }
        return workBook;
    }

    public String readTestData(String ApplicationName,String SheetName, String ColumnName) {               
        String Value = null;
        boolean ext = false;
        try {

            if (!getTestDataSheet(ApplicationName)) {
                throw new Exception(ApplicationName + " is not available under " + testDataFilePath);
            }
            setWorkSheet(getWorkBook(ApplicationName).getSheet(SheetName));
            int colNum = getWorkSheet().getRow(0).getPhysicalNumberOfCells();
            outerloop: for (int i = 0; i <= colNum - 1; i++) {
                if (getWorkSheet().getRow(0).getCell(i).toString().equals(ColumnName)) {
                    Value = getWorkSheet().getRow(1).getCell(i).toString();
                    ext = true;
                    break outerloop;
                }
            }
            if (!ext) {
                throw new Exception(ColumnName + " is not available");
            }

        } catch (Exception e) {

            System.out.println(e);
        }
        return Value;
    }

    

    public XSSFSheet getWorkSheet() {
        return workSheet;
    }

    public void setWorkSheet(XSSFSheet workSheet) {

        this.workSheet = workSheet;
    }

    public Map<String, Map<String, String>> readAPIData(String ApplicationName, String SheetName) {
        Map<String, Map<String, String>> data = new LinkedHashMap<String, Map<String, String>>();

        try {

            if (!getTestDataSheet(ApplicationName)) {
                throw new Exception(ApplicationName + " is not available under " + testDataFilePath);
            }
            setWorkSheet(getWorkBook(ApplicationName).getSheet(SheetName));
            int rowNum = getWorkSheet().getLastRowNum();
            int colNum = getWorkSheet().getRow(0).getPhysicalNumberOfCells();
            for (int i = 1; i <= rowNum; i++) {
                Map<String, String> data1 = new LinkedHashMap<String, String>();
                Row row = getWorkSheet().getRow(i);
                for (int j = 1; j <= colNum; j++) {
                    if (row.getCell(j) != null) {
                        data1.put(getWorkSheet().getRow(0).getCell(j).toString() + i, row.getCell(j).toString());
                    }
                }
                data.put(row.getCell(0).toString().trim(), data1);
            }

        } catch (Exception e) {

            System.out.println(e);
        }
        return data;
    }

    public Map<String, String> getAPIMap(String applicationName,String sheetName, String ScenarioName) {
        return readAPIData(applicationName, sheetName).get(ScenarioName);
    }

    public String getScenarioLevelTestData(String ApplicationName,String sheetname, String ScenarioName, String ColumnName) {
        String Value = null;
        try {
            Map<String, String> data = readAPIData(ApplicationName, sheetname).get(ScenarioName);
            for (Map.Entry<String, String> entry : data.entrySet()) {
                if (entry.getKey().contains(ColumnName)) {
                    Value = entry.getValue();
                    break;
                }
            }
        } catch (Exception e) {

            System.out.println(e);
        }
        if (Value == null) {
            Value = "";
        }
        return Value;
    }
    
    public int getScenarioLevelTestDataSteps(String ApplicationName,String sheetname, String ScenarioName, String ColumnName) {
        int Value = 0;
        try {
            Value= readAPIData(ApplicationName, sheetname).size();
            
                        
        } catch (Exception e) {

            System.out.println(e);
        }
        
        return Value;
    }
    
    public void setTestDataPath() {      
            
                testDataFilePath = System.getProperty("user.dir") + "/src/test/resources/TestData";         
        
    }

    public String getTestDataPath() {
        
        return testDataFilePath;
    }
    
    public String getIterationSheetData(String ApplicationName, String index,String ColumnName) {
        String Value = null;
        boolean ext = false;
        int r=Integer.parseInt(index);
        try {

            if (!getTestDataSheet(ApplicationName)) {
                throw new Exception(ApplicationName + " is not available under " + testDataFilePath);
            }
            setWorkSheet(getWorkBook(ApplicationName).getSheet("Iteration"));
            int rowNum = getWorkSheet().getLastRowNum();
            int colNum = getWorkSheet().getRow(0).getPhysicalNumberOfCells();
            outerloop:for (int i = 1; i <= rowNum; i++) {
                Row row = getWorkSheet().getRow(i);
                for (int j = 1; j <= colNum; j++) {
                    if (getWorkSheet().getRow(0).getCell(j).toString().equals(ColumnName)) {
                        Value = getWorkSheet().getRow(r).getCell(j).toString();
                        break outerloop;
                    }
                    
                }
                
            }

        } catch (Exception e) {

            System.out.println(e);
        }
        return Value;
    }
}