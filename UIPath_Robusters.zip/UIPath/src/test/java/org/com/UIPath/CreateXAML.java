package org.com.UIPath;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class CreateXAML {
	static ExcelUtilities excel = new ExcelUtilities();
	public static void main(String[] args) throws IOException {
		List<String> list = new ArrayList<String>();
		String FileName = excel.getScenarioLevelTestData("UIPath", "Sheet", "Step1", "XAMLFileName");
		int size = excel.getScenarioLevelTestDataSteps("UIPath", "Sheet", "Step1", "Action");
		for(int i=0;i<size;i++)
		{
			String some1 = excel.getScenarioLevelTestData("UIPath", "Sheet", "Step"+(i+1), "Action");
			list.add(some1);
		}
		createXAMLFile(FileName,list);
	}
	public static void createXAMLFile(String FileName, List<String> actions) throws IOException
	{
		String some = readFile();
		
		some = some.replace("FileName", FileName);
		
		
		
		for(int i=0;i<actions.size();i++)
		{
			String Action = actions.get(i);
			String actionSnippet = getActionSnippet(Action);
			if(i == actions.size()-1)
			{
				some = some.replace("AddYourCode", actionSnippet);
			}
			else
			{
				some = some.replace("AddYourCode", actionSnippet+"\n"+"AddYourCode");
			}
			
		}
		
		System.out.println(""+some);
		
		String FileName1 = System.getProperty("user.dir")+"\\src\\test\\resources\\Output\\"+FileName+".xaml";
		PrintWriter writer = new PrintWriter(FileName1, "UTF-8");
        writer.println(some);         
         writer.close();
	}	
	static String readFile() throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(System.getProperty("user.dir")+"\\src\\test\\resources\\sample.txt"));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        return sb.toString();
	    } finally {
	        br.close();
	    }
	}
	
	public static String getActionSnippet(String Action)
	{
		String ActionSnippet = "";
		if(Action.equalsIgnoreCase("openbrowser") || Action.equalsIgnoreCase("open browser"))
		{
			ActionSnippet = "<ui:OpenBrowser UiBrowser=\"{x:Null}\" Url=\"{x:Null}\" BrowserType=\"IE\" DisplayName=\"Open Browser\" Hidden=\"False\" NewSession=\"True\" Private=\"False\">\r\n" + 
					"      <ui:OpenBrowser.Body>\r\n" + 
					"        <ActivityAction x:TypeArguments=\"x:Object\">\r\n" + 
					"          <ActivityAction.Argument>\r\n" + 
					"            <DelegateInArgument x:TypeArguments=\"x:Object\" Name=\"ContextTarget\" />\r\n" + 
					"          </ActivityAction.Argument>\r\n" + 
					"        </ActivityAction>\r\n" + 
					"      </ui:OpenBrowser.Body>\r\n" + 
					"    </ui:OpenBrowser>"; 
		}
		else if(Action.contains("Type") || Action.contains("type") || Action.equalsIgnoreCase("TypeInto") || Action.equalsIgnoreCase("Type Into"))
		{
			ActionSnippet = "<ui:TypeInto DelayBefore=\"{x:Null}\" DelayBetweenKeys=\"{x:Null}\" DelayMS=\"{x:Null}\" Text=\"{x:Null}\" Activate=\"True\" ClickBeforeTyping=\"False\" EmptyField=\"False\" SendWindowMessages=\"False\" SimulateType=\"False\">\r\n" + 
					"      <ui:TypeInto.Target>\r\n" + 
					"        <ui:Target ClippingRegion=\"{x:Null}\" Element=\"{x:Null}\" Selector=\"{x:Null}\" TimeoutMS=\"{x:Null}\" WaitForReady=\"INTERACTIVE\" />\r\n" + 
					"      </ui:TypeInto.Target>\r\n" + 
					"    </ui:TypeInto>";
		}
		else if(Action.equalsIgnoreCase("click"))
		{
			ActionSnippet = "<ui:Click DelayBefore=\"{x:Null}\" DelayMS=\"{x:Null}\" ClickType=\"CLICK_SINGLE\" KeyModifiers=\"None\" MouseButton=\"BTN_LEFT\" SendWindowMessages=\"False\" SimulateClick=\"False\">\r\n" + 
					"      <ui:Click.CursorPosition>\r\n" + 
					"        <ui:CursorPosition Position=\"Center\">\r\n" + 
					"          <ui:CursorPosition.OffsetX>\r\n" + 
					"            <InArgument x:TypeArguments=\"x:Int32\" />\r\n" + 
					"          </ui:CursorPosition.OffsetX>\r\n" + 
					"          <ui:CursorPosition.OffsetY>\r\n" + 
					"            <InArgument x:TypeArguments=\"x:Int32\" />\r\n" + 
					"          </ui:CursorPosition.OffsetY>\r\n" + 
					"        </ui:CursorPosition>\r\n" + 
					"      </ui:Click.CursorPosition>\r\n" + 
					"      <ui:Click.Target>\r\n" + 
					"        <ui:Target ClippingRegion=\"{x:Null}\" Element=\"{x:Null}\" Selector=\"{x:Null}\" TimeoutMS=\"{x:Null}\" WaitForReady=\"INTERACTIVE\" />\r\n" + 
					"      </ui:Click.Target>\r\n" + 
					"    </ui:Click>";
		}
		else if(Action.equalsIgnoreCase("highlight"))
		{
			ActionSnippet = "<ui:Highlight HighlightTime=\"{x:Null}\" Color=\"Red\">\r\n" + 
					"      <ui:Highlight.Target>\r\n" + 
					"        <ui:Target ClippingRegion=\"{x:Null}\" Element=\"{x:Null}\" Selector=\"{x:Null}\">\r\n" + 
					"          <ui:Target.TimeoutMS>\r\n" + 
					"            <InArgument x:TypeArguments=\"x:Int32\" />\r\n" + 
					"          </ui:Target.TimeoutMS>\r\n" + 
					"          <ui:Target.WaitForReady>\r\n" + 
					"            <InArgument x:TypeArguments=\"ui:WaitForReady\" />\r\n" + 
					"          </ui:Target.WaitForReady>\r\n" + 
					"        </ui:Target>\r\n" + 
					"      </ui:Highlight.Target>\r\n" + 
					"    </ui:Highlight>";
		}
		else if(Action.contains("screenshot") || Action.equalsIgnoreCase("Take Screenshot"))
		{
			ActionSnippet = "<ui:TakeScreenshot Screenshot=\"{x:Null}\" WaitBefore=\"{x:Null}\">\r\n" + 
					"      <ui:TakeScreenshot.Target>\r\n" + 
					"        <ui:Target ClippingRegion=\"{x:Null}\" Element=\"{x:Null}\" Selector=\"{x:Null}\">\r\n" + 
					"          <ui:Target.TimeoutMS>\r\n" + 
					"            <InArgument x:TypeArguments=\"x:Int32\" />\r\n" + 
					"          </ui:Target.TimeoutMS>\r\n" + 
					"          <ui:Target.WaitForReady>\r\n" + 
					"            <InArgument x:TypeArguments=\"ui:WaitForReady\" />\r\n" + 
					"          </ui:Target.WaitForReady>\r\n" + 
					"        </ui:Target>\r\n" + 
					"      </ui:TakeScreenshot.Target>\r\n" + 
					"    </ui:TakeScreenshot>";
		}	
		return ActionSnippet;		
	}
}
